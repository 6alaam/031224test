package fractal;

public class Mandelbrot extends Fractal {
	public String getName() {
		return "mandelbrot";
	}

	public Mandelbrot() {
		n = 18;
	}
}